# Independent program review: onehand

## Exact-tree review record

```json
{
  "format": "ak820-ci-program-review-1",
  "hardware_validated": false,
  "ihx_sha256": "32bfa36b3b5a9d4b674b69d0b55b891045c43d575c716384aa77a6ebe6e6b99e",
  "physical_device_commands": 0,
  "policy_sha256": "f235d328e8face725c4787d2132e212b19d0c5a3398aec90733307aeae394fc0",
  "profile": "onehand",
  "review_report": "ci/profiles/onehand/program-review.md#exact-tree-review-record",
  "scope": "Independent beta.4 exact-tree policy/evidence review recorded in this file (2026-10-28). Verified this profile's current policy source/host/witness manifests against worktree bytes; current linked IHX and canonical MAP symbol identity; matching packing receipt digest/program identity; and passing unchanged-build qualification at `qmk-8051-ak820/.build/onehand-preliminary-final/onehand/qualification.json` (28 suites, 353 unit tests, zero skips). The beta.3/current-only settings transition matrix passed the repository validator. Scope is artifact, source-binding and evidence integrity; it does not assess all firmware behavior or establish hardware validation, release approval, or publication.",
  "status": "passed",
  "symbols_sha256": "5ee5899bfa10afa5d5d9a176ce774144015017ca9f72ff06f0ed5fa598390183",
  "test_source_snapshot_sha256": "0eff203551cefa725d98822eea494713a0a4837da52b8b9966e6a66fb312b7eb"
}
```
