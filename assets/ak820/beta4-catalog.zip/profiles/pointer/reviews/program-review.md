# Independent program review: pointer

## Exact-tree review record

```json
{
  "format": "ak820-ci-program-review-1",
  "hardware_validated": false,
  "ihx_sha256": "c08d1bfefb705df10c17b545d90d156708f0482464de0e9e0aeb66afeb5ba19e",
  "physical_device_commands": 0,
  "policy_sha256": "7d74c04c27600f31a48ccad15ba69e2f2189b307f8d1825863be2284d33b369f",
  "profile": "pointer",
  "review_report": "ci/profiles/pointer/program-review.md#exact-tree-review-record",
  "scope": "Independent beta.4 exact-tree policy/evidence review recorded in this file (2026-10-28). Verified this profile's current policy source/host/witness manifests against worktree bytes; current linked IHX and canonical MAP symbol identity; matching packing receipt digest/program identity; and passing unchanged-build qualification at `qmk-8051-ak820/.build/glibc-pointer-profiles/pointer/qualification.json` (28 suites, 353 unit tests, zero skips). The beta.3/current-only settings transition matrix passed the repository validator. Scope is artifact, source-binding and evidence integrity; it does not assess all firmware behavior or establish hardware validation, release approval, or publication.",
  "status": "passed",
  "symbols_sha256": "7e8868421c97a5ac199036026203946799b0bdd997706a965d96ab53806e5521",
  "test_source_snapshot_sha256": "0eff203551cefa725d98822eea494713a0a4837da52b8b9966e6a66fb312b7eb"
}
```
