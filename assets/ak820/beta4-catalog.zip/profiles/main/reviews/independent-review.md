# Reproduced CI build

This record confirms that an offline CI run reproduced the program approved by the program policy. It is a machine record, not a claim of independent human review or hardware validation.

```json
{
  "format": "ak820-reproduced-review-1",
  "release": "rc6",
  "status": "passed",
  "hardware_validated": false,
  "source_commit": "1c3cbcd6232db8a1e1b6877f7993df186081edcd",
  "policy_sha256": "7530acc3877c723eaf31a6c8ec148c065af1ee42c84d3a27e67f9125f26a5a3d",
  "program_review_sha256": "640c3fcc8c026a5f1dfeb6926027d3db39ee61b375beec33683adf6fbd3918ae",
  "build": {
    "ihx_sha256": "05f49d16b380a8f40b55c3a38c0e863a25d884237d4fd8d6aaef51b6fd95c389",
    "map_sha256": "a75902721381da5d78228d4f6c2ab305bd058065c43e2045626329d373837fe6",
    "build_report_sha256": "505669016020068834ae49814ab68eb583ade669ffcfa81ac3e70401c6d8a106"
  },
  "host_files": {
    "AK820.cmd": {
      "size": 304,
      "sha256": "6ac919855c075fdac596fe15ec2f27682388498a863c2c0dd1a6f7737e09799d"
    },
    "AK820.sh": {
      "size": 515,
      "sha256": "9a8ebbc2ed64d2d0ac6ea7f4d1251d5de630c8af78465dee3acfdc833b4528fb"
    },
    "qmk-8051-ak820/util/ak820_ci_authorization.py": {
      "size": 14511,
      "sha256": "da9f487b214e23c66cb88b436ea42b5025a61de03ea43153fa354172b89a6032"
    },
    "qmk-8051-ak820/util/ak820_diagnose.py": {
      "size": 14347,
      "sha256": "4833247da16ab7557eca9ae67d0fda9f5952d406f68aead4407baf40bac771b8"
    },
    "qmk-8051-ak820/util/ak820_extension_settings.py": {
      "size": 5448,
      "sha256": "d30ae8eb992006781a3639e7e7c7f71e568e571b919817e75e4911680bd7f8f0"
    },
    "qmk-8051-ak820/util/ak820_profiles.py": {
      "size": 13600,
      "sha256": "b3dfc0d1174898ca656cda1a7aaae650d36a0ccc25f1bdf6c5b715bcc3398f24"
    },
    "qmk-8051-ak820/util/ak820_release_manifest.py": {
      "size": 2588,
      "sha256": "e18080f107bb58640dbdaf7c3a245cf4f8a1dd7885930a5cad44503407794fd7"
    },
    "qmk-8051-ak820/util/ak820_tool.py": {
      "size": 23134,
      "sha256": "87229c0fb92dcbbcc0d60f3d75ed43f459647c5a0fccf7cc57e0dd36bb884f0b"
    },
    "qmk-8051-ak820/util/native_macro_import.py": {
      "size": 2499,
      "sha256": "572f153de6ec9a71eefa8fd87c5ba2bd7da602619131e3ec66fa63d9a742b07f"
    },
    "qmk-8051-ak820/util/pack_ak820.py": {
      "size": 27210,
      "sha256": "d392ed795cf34f3c0e1a2e58e07b5a35f1e14500c5bd91c6bcaccfd4f9a7cc7c"
    },
    "qmk-8051-ak820/util/prepare_ak820_trial.py": {
      "size": 6340,
      "sha256": "c6eccf3dae1eecf9449cab71b2d12786129235968066156a40991764dacd40a2"
    },
    "tools/ak820_device_protocol.py": {
      "size": 36314,
      "sha256": "86868d094ed6d225329f21598b62bcfc34d03f053ee063c76795267dfb9ff71d"
    },
    "tools/build_ci_release.py": {
      "size": 35652,
      "sha256": "89b72e2860e4ada4a2c1f00984beeb623bfa9d0c63278954769ab51d3d67bfe3"
    },
    "tools/build_release_bundle.py": {
      "size": 13621,
      "sha256": "428058ae243bfc716d2890fabefd5af8210a88058f79fa9e047d145ee5b2771d"
    },
    "tools/installer/70-ak820.rules": {
      "size": 339,
      "sha256": "f0b85bb730963057350a6a9cfe35e1f17e2859a5bfbcebfce9fccaa6534a3a52"
    },
    "tools/installer/ak820.py": {
      "size": 57815,
      "sha256": "6ce93cce23a6b8fc5be0032ad46eb7c7034cc23131de8a1c5985354ada474c22"
    },
    "tools/installer/i18n.py": {
      "size": 21250,
      "sha256": "94901c2826c7936410f9e799518c4a6ccdff7d1800f10784d03d81c53dc45dd5"
    },
    "tools/installer/profile-catalog.json": {
      "size": 7176,
      "sha256": "2142f639846930dd267556d5218c12743727e73f9e56ecc2a1d974bcf0758423"
    },
    "tools/installer/requirements.txt": {
      "size": 15,
      "sha256": "6e78c6c5a61dbebf36f570a14685c795efcdb3d8bb6b6118b6aa78dd0aca54d4"
    },
    "tools/installer/settings-catalog.json": {
      "size": 5049090,
      "sha256": "8bf90526a51e9879870a61d7de1c59b1df38e3489b77a67e67496503f0307658"
    },
    "tools/installer/settings_backup.py": {
      "size": 58158,
      "sha256": "02e641b3e3af8c84a047bec34574fe9cc91c05ee0f976576afe242b3c5eab292"
    },
    "tools/installer/settings_workflow.py": {
      "size": 12798,
      "sha256": "739b941cb1724fdf08b9fb5d798adec507260c22a2d97cdcd02ce7f1247bb26f"
    }
  },
  "attestation_sha256": "d42c28c4f2f02835c225d03a501a18ebef36173b9c213cb5dee0d8fd557ae946"
}
```
